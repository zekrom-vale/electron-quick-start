                                        # [ continuing from file ./f2.R  (yuck!!!) ]
  # return
  (y - x)^2
#> } # << closing brace "accidentally" commented out (in *one* version of this file/pkg)

f3 <- \(x) exp(-x^2/2)

