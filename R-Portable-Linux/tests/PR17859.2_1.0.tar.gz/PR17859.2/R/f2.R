f2ok  <- \(x) log1p(x^2)
#
f2in2 <- \(x) {
    y <- x^2
    ## to be continued in next file -- accidentally "ok" in R <= 4.2.x
