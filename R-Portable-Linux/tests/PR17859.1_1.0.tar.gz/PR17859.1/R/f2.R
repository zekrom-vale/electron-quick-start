f2ok    <- \(x) log1p(x^2)
## parse error .... unexpected symbol
f2wrong <-  (x) log1p(x^2)
## well detected, including file name, line & column number during 'R CMD INSTALL'
