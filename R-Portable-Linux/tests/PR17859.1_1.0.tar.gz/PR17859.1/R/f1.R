f1 <- \(x) sin(pi/2*x)
