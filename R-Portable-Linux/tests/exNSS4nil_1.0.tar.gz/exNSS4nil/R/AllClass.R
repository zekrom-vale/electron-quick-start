#setClass("track", slots = c(x="numeric", y="numeric"))

some.object <- pi
