setClass("subClass", contains = "pubClass",
         # additional slots
         slots = c(zip = "integer",
                   names = "character"))
